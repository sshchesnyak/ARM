#include "tms320.h"
#include "test.h"

extern int mpy_ll_int(long long, int);
extern ushort dlms(DATA *x, DATA *h, DATA *r, DATA *des, DATA *dbuffer, DATA step, ushort nh, ushort nx);
void dlms_test(DATA *x, DATA *h, DATA *r, DATA *des, DATA *dbuffer, DATA step, ushort nh, ushort nx);

int ac3v[NX];

int main(void) {

	DATA i, j, err, max_err_r, max_err_h;

	for(j=0; j<2; j++){
		for (i = 0; i< NH; i++)
		{
			h[i] = 0;	// clear coeff buffer (optional)
			hn[i] = 0;
		}
		for (i = 0; i< NX; i++){
			r[i] = 0;	// clear output buffer (optional)
			rn[i] = 0;
		}

		dbuffer[0] = 0;             // clear index
		ndbuffer[0] = 0;
		for (i = 0; i < NH+2; i++){
			dbuffer[i] = 0; // clear delay buffer (a must)
			ndbuffer[i] = 0;
		}

		// compute
		dlms(x, h, r, des, dbuffer, STEP, NH, NX);
		dlms_test(x, hn, rn, des, ndbuffer, STEP, NH, NX);
	}

	max_err_r = 0;
	for(i = 0; i < NX; i++)
	{
		err = _abss(r[i] - rn[i]);
		if(err > max_err_r)
			max_err_r = err;
	}
	max_err_h = 0;
	for(i = 0; i < NH; i++)
	{
		err = _abss(h[i] - hn[i]);
		if(err > max_err_h)
			max_err_h = err;
	}
	return 0;
}

void dlms_test(DATA *x, DATA *h, DATA *r, DATA *des, DATA *dbuffer, DATA step, const ushort nh, const ushort nx)
{
	int *ar_data;
	int *coef_data;
	long long ac0, ac1;
	int i, j, data_index, ac3, n_iter;

	ar_data = (int*) (dbuffer+1);
	data_index = dbuffer[0];
	ac3 = 0;

	for(i = 0; i < nx; i++)
	{
		coef_data = (int*) h;
		*(ar_data + data_index) = x[i];
		data_index = _circ_incr(data_index, 1, nh+1);
		ac1 = 0;
		j = 0;

		//Iterations before data_index reaches maximum
		n_iter = (data_index < 2) ? nh - 1 : nh - data_index;
		while(j < n_iter)
		{
			ac0 = _llsmpy(*(ar_data + data_index), ac3);
			data_index++;
			_llslms(coef_data, (ar_data + data_index), ac0, ac1);
			*coef_data++ = (int) (ac0 >> 16);
			j++;
		}
		//Last iteration uses circular increment of data_index - we could skip max
		ac0 = _llsmpy(*(ar_data + data_index), ac3);
		data_index = _circ_incr(data_index, 1, nh+1);
		_llslms(coef_data, (ar_data + data_index), ac0, ac1);
		*coef_data++ = (int) (ac0 >> 16);
		j++;

		//Iterations after data_index reaches maximum (if we have some)
		if(j < nh)
		{
			n_iter = nh - n_iter - 1;
			j = 0;

			while(j < n_iter)
			{
				ac0 = _llsmpy(*(ar_data + data_index), ac3);
				data_index++;
				_llslms(coef_data, (ar_data + data_index), ac0, ac1);
				*coef_data++ = (int) (ac0 >> 16);
				j++;
			}
		}

		r[i] = (DATA) (ac1 >> 16);
		data_index = _circ_incr(data_index, 1, nh+1);

		ac0 = (long long) des[i] - (ac1 >> 16);
		ac3 = mpy_ll_int(ac0, step);

	}
	dbuffer[0] = data_index;
}

